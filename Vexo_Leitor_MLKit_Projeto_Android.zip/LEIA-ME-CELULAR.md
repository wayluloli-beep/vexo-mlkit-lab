# VEXO · ML Kit 0.1 — Projeto Android

Este arquivo ZIP é **o código-fonte do leitor**, não um APK pronto. Ele foi projetado para usar o Google ML Kit Text Recognition v2, com o modelo embarcado para reconhecimento local.

## O que o app faz
1. Abre o seletor de imagens do Android.
2. Você seleciona um print real de uma oferta Uber/99.
3. ML Kit lê o texto da imagem no aparelho.
4. Mostra o texto bruto, permitindo copiar e comparar com o gabarito que você extraiu.

## O que ainda NÃO faz
- Não identifica automaticamente qual número corresponde ao valor da oferta.
- Não aprende sozinho com correções.
- Não captura telas de outros apps nem toca em botões da Uber/99.
- Não envia prints para servidores nem pede permissão de Internet.
- Não é o Vexo completo, apenas o laboratório separado.
- O APK **ainda não foi compilado nem testado em um Android físico**.

## Como compilar sem computador (GitHub)
1. Acesse github.com e crie um repositório **privado** chamado `vexo-mlkit-lab`.
2. O repositório precisa conter **as pastas e arquivos deste ZIP**, preservando sua estrutura (não basta subir o ZIP fechado). Se o navegador do celular não permitir o upload de pastas, use o editor do GitHub Codespaces para descompactar e adicionar os arquivos ao repositório. Você pode pedir ajuda passo a passo nesta conversa.
3. Em `Actions`, execute `Gerar APK Vexo ML Kit` (ou deixe o primeiro push acionar a compilação).
4. Quando o build estiver verde, abra o run e baixe o artefato `Vexo-MLKit-Leitor-APK`.
5. Extraia o APK do artefato ZIP e instale no seu próprio Android. Instale **somente** se o arquivo veio do seu repositório privado e você confia no código. É um APK de teste, não assinado para publicação na Play Store.
6. Abra o app e selecione um dos prints que você extraiu. Confira o texto bruto com `rotulos_vexo_ocr.json`.

## Privacidade
**Não suba os prints de corrida a um repositório público.** Os prints mostram endereços e informações potencialmente pessoais. O projeto-fonte não inclui os prints. O conteúdo lido fica na tela e não é guardado pelo app.

## Referências
- https://developers.google.com/ml-kit/vision/text-recognition/v2/android
- https://github.com/gradle/actions/blob/main/docs/setup-gradle.md
