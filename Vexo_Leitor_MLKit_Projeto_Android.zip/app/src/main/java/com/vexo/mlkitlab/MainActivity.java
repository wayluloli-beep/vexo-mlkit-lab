package com.vexo.mlkitlab;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 42;
    private TextView output;
    private TextView status;
    private String lastText = "";
    private Button pickButton;

    private int px(float dp) { return (int)(dp * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(px(radius));
        return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        int dark=Color.rgb(11,15,22), card=Color.rgb(25,31,42), blue=Color.rgb(24,184,211);
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(dark);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(px(22),px(36),px(22),px(26));
        scroll.addView(root);
        TextView logo=text("VEXO",32,blue,true);
        root.addView(logo);
        TextView title=text("Leitor de prints · laboratório 0.1",17,Color.WHITE,true);
        LinearLayout.LayoutParams ttl=new LinearLayout.LayoutParams(-1,-2); ttl.topMargin=px(8);
        root.addView(title,ttl);
        TextView desc=text("Escolha um print da 99 ou Uber. O Google ML Kit vai reconhecer o texto dentro do próprio celular. Nesta versão ele ainda não classifica valor, km ou tempo.",14,0xFFB2BCCA,false);
        LinearLayout.LayoutParams ds=new LinearLayout.LayoutParams(-1,-2); ds.topMargin=px(12);
        root.addView(desc,ds);
        pickButton=new Button(this);
        pickButton.setAllCaps(false);
        pickButton.setText("Escolher print da galeria");
        pickButton.setTextColor(Color.BLACK);
        pickButton.setBackground(bg(blue,14));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,px(52)); bp.topMargin=px(26);
        root.addView(pickButton,bp);
        pickButton.setOnClickListener(v -> chooseImage());
        status=text("Nenhuma imagem selecionada",14,0xFFB2BCCA,false);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=px(18);
        root.addView(status,sp);
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackground(bg(card,16));
        box.setPadding(px(16),px(16),px(16),px(16));
        LinearLayout.LayoutParams boxp=new LinearLayout.LayoutParams(-1,-2); boxp.topMargin=px(16);
        root.addView(box,boxp);
        box.addView(text("Texto reconhecido",16,Color.WHITE,true));
        output=text("O resultado da leitura vai aparecer aqui. Ele pode conter erros e deve ser conferido no print original.",15,0xFFD9E4EA,false);
        output.setTextIsSelectable(true);
        LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,-2); op.topMargin=px(12);
        box.addView(output,op);
        Button copy=new Button(this);
        copy.setAllCaps(false);
        copy.setText("Copiar texto reconhecido");
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,px(52)); cp.topMargin=px(18);
        root.addView(copy,cp);
        copy.setOnClickListener(v -> {
            if (lastText.isEmpty()) { Toast.makeText(this,"Leia um print primeiro",Toast.LENGTH_SHORT).show(); return; }
            ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Vexo OCR",lastText));
            Toast.makeText(this,"Texto copiado. Confira antes de compartilhar.",Toast.LENGTH_SHORT).show();
        });
        TextView safety=text("Privacidade: não solicita internet nem envia imagens a servidores. O reconhecimento usa o modelo ML Kit embarcado. Os textos só são copiados se você apertar o botão.",12,0xFF8FA0AC,false);
        LinearLayout.LayoutParams safeP=new LinearLayout.LayoutParams(-1,-2); safeP.topMargin=px(16);
        root.addView(safety,safeP);
        setContentView(scroll);
    }

    private void chooseImage() {
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent,PICK_IMAGE);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode!=PICK_IMAGE || resultCode!=RESULT_OK || data==null || data.getData()==null) return;
        Uri uri=data.getData();
        pickButton.setEnabled(false);
        status.setText("Lendo imagem com o Google ML Kit...");
        output.setText("Processando...");
        try {
            InputImage input=InputImage.fromFilePath(this,uri);
            com.google.mlkit.vision.text.TextRecognizer reader=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            reader.process(input)
                .addOnSuccessListener(result -> {
                    lastText=result.getText();
                    output.setText(lastText.isEmpty()?"Nenhum texto foi identificado nesta imagem.":lastText);
                    status.setText("Leitura concluída (confira com a imagem original)");
                })
                .addOnFailureListener(err -> {
                    lastText="";
                    output.setText("Não foi possível ler esta imagem. Tente outro print.");
                    status.setText("Falha no reconhecimento: " + err.getClass().getSimpleName());
                })
                .addOnCompleteListener(task -> { reader.close(); pickButton.setEnabled(true); });
        } catch (Exception e) {
            lastText="";
            output.setText("O Android não conseguiu abrir esta imagem.");
            status.setText("Erro: " + e.getClass().getSimpleName());
            pickButton.setEnabled(true);
        }
    }
}
